package vendingmachine.data;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Admin şifresini dosyaya okur/yazar.
 * Hem konsol (AdminLogic) hem de GUI (TestGUI, AdminGUI) tarafından kullanılır.
 *
 * Şifre dosyası bulunamazsa varsayılan şifre "admin1234" kullanılır.
 */
public class FileManager {

    private static final String PASSWORD_FILE    = "admin_password.txt";
    private static final String DEFAULT_PASSWORD = "admin1234";

    /** Girilen şifreyi kayıtlı şifreyle karşılaştırır. */
    public boolean checkAdminPassword(String inputPassword) {
        if (inputPassword == null) return false;
        return getStoredPassword().equals(inputPassword.trim());
    }

    /** Yeni şifreyi dosyaya kaydeder. */
    public void saveAdminPassword(String newPassword) {
        try {
            Files.write(
                Paths.get(PASSWORD_FILE),
                newPassword.trim().getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (IOException e) {
            System.err.println("[FileManager] Şifre kaydedilemedi: " + e.getMessage());
        }
    }

    // ── Yardımcı ─────────────────────────────────────────────

    private String getStoredPassword() {
        try {
            Path path = Paths.get(PASSWORD_FILE);
            if (Files.exists(path)) {
                return new String(Files.readAllBytes(path), StandardCharsets.UTF_8).trim();
            }
        } catch (IOException e) {
            System.err.println("[FileManager] Şifre dosyası okunamadı: " + e.getMessage());
        }
        return DEFAULT_PASSWORD;   // dosya yoksa varsayılan
    }
}
