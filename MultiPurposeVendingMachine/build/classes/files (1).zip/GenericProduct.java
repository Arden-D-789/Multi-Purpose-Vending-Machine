package vendingmachine.products;

/**
 * Genel amaçlı somut ürün sınıfı.
 * Yiyecek, içecek veya herhangi bir kalem olabilir.
 */
public class GenericProduct extends AbstractProduct {

    public GenericProduct(String slotId, String name, double price, int stockQuantity) {
        super(slotId, name, price, stockQuantity);
    }

    @Override
    public void displayInfo() {
        System.out.println("  +---------------------------------+");
        System.out.printf ("  | Slot  : %-23s |%n", slotId);
        System.out.printf ("  | Ürün  : %-23s |%n", name);
        System.out.printf ("  | Fiyat : $%-22.2f |%n", price);
        System.out.printf ("  | Stok  : %-23d |%n", stockQuantity);
        System.out.printf ("  | Durum : %-23s |%n", isAvailable() ? "Mevcut" : "TÜKENDİ");
        System.out.println("  +---------------------------------+");
    }
}
