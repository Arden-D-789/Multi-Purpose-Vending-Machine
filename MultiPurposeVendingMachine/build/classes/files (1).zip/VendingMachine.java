package vendingmachine;

import java.util.*;
import vendingmachine.products.AbstractProduct;
import vendingmachine.products.GenericProduct;

/**
 * Otomatın temel motoru.  Singleton pattern ile kullanılır.
 * Hem Main (konsol) hem de GUI tarafından ortak olarak kullanılır.
 */
public class VendingMachine {

    // ── Singleton ─────────────────────────────────────────────
    private static VendingMachine instance;

    public static VendingMachine getInstance() {
        if (instance == null) {
            instance = new VendingMachine();
        }
        return instance;
    }

    // ── Durum ─────────────────────────────────────────────────
    private final Map<String, AbstractProduct> inventory = new LinkedHashMap<>();
    private double totalRevenue = 0.0;

    private static final int LOW_STOCK_THRESHOLD = 3;

    // ── Constructor ───────────────────────────────────────────
    private VendingMachine() {
        loadDefaultInventory();
    }

    private void loadDefaultInventory() {
        add("A1", "Cola",          1.50, 10);
        add("A2", "Diet Cola",     1.50,  8);
        add("A3", "Lemonade",      1.75,  6);
        add("B1", "Chips",         1.25,  5);
        add("B2", "Pretzels",      1.00,  4);
        add("B3", "Cookies",       1.50,  2);   // düşük stok örneği
        add("C1", "Water",         1.00, 12);
        add("C2", "Orange Juice",  2.00,  7);
        add("C3", "Sandwich",      3.50,  3);   // düşük stok örneği
        add("D1", "Chocolate",     1.75,  9);
        add("D2", "Gum",           0.75, 15);
        add("D3", "Granola Bar",   2.25,  1);   // düşük stok örneği
    }

    private void add(String slot, String name, double price, int qty) {
        inventory.put(slot, new GenericProduct(slot, name, price, qty));
    }

    // ── Envanter erişimi ──────────────────────────────────────

    /** Değiştirilemez envanter haritasını döndürür. */
    public Map<String, AbstractProduct> getInventory() {
        return Collections.unmodifiableMap(inventory);
    }

    /**
     * Slot'a göre ürün döndürür; bulunamazsa exception fırlatır.
     * Main.java viewProductDetail() tarafından kullanılır.
     */
    public AbstractProduct getProductOrThrow(String slot) throws ProductNotFoundException {
        AbstractProduct p = inventory.get(slot.toUpperCase());
        if (p == null) {
            throw new ProductNotFoundException("Slot '" + slot + "' bulunamadı.");
        }
        return p;
    }

    /** Slot'a göre ürün döndürür; bulunamazsa null döner. */
    public AbstractProduct getProduct(String slot) {
        return inventory.get(slot.toUpperCase());
    }

    /** Düşük stoklu ürünleri liste olarak döndürür. */
    public List<AbstractProduct> getLowStockProducts() {
        List<AbstractProduct> result = new ArrayList<>();
        for (AbstractProduct p : inventory.values()) {
            if (p.getStockQuantity() <= LOW_STOCK_THRESHOLD) {
                result.add(p);
            }
        }
        return result;
    }

    /** Tüm envanteri konsola formatlanmış olarak yazdırır. */
    public void printInventory() {
        System.out.println("\n  +======================================+");
        System.out.println("  |          ÜRÜN ENVANTERİ              |");
        System.out.println("  +------+------------------+-------------+");
        System.out.printf ("  | %-4s | %-16s | %-11s |%n", "Slot", "İsim", "Fiyat/Stok");
        System.out.println("  +------+------------------+-------------+");
        for (Map.Entry<String, AbstractProduct> e : inventory.entrySet()) {
            AbstractProduct p = e.getValue();
            if (p.isAvailable()) {
                System.out.printf("  | %-4s | %-16s | $%-4.2f (%-3d) |%n",
                    e.getKey(), p.getName(), p.getPrice(), p.getStockQuantity());
            } else {
                System.out.printf("  | %-4s | %-16s | [TÜKENDİ]   |%n",
                    e.getKey(), p.getName());
            }
        }
        System.out.println("  +======================================+");
    }

    // ── Satış işlemi ──────────────────────────────────────────

    /**
     * Satışı gerçekleştirir: stok düşer, gelire eklenir.
     * @return Başarılıysa true
     */
    public synchronized boolean processSale(String slot, double amountPaid) {
        AbstractProduct p = inventory.get(slot.toUpperCase());
        if (p == null || !p.isAvailable()) return false;
        if (!p.decrementStock()) return false;
        totalRevenue += p.getPrice();
        return true;
    }

    // ── Yönetici işlemleri ────────────────────────────────────

    public void addNewProduct(String slot, String name, double price, int stock) {
        inventory.put(slot.toUpperCase(), new GenericProduct(slot.toUpperCase(), name, price, stock));
    }

    public void restock(String slot, int amount) throws ProductNotFoundException {
        getProductOrThrow(slot).addStock(amount);
    }

    public void reprice(String slot, double newPrice) throws ProductNotFoundException {
        getProductOrThrow(slot).setPrice(newPrice);
    }

    public double getTotalRevenue() { return totalRevenue; }

    /** Geliri sıfırlayarak mevcut değeri döndürür. */
    public double collectRevenue() {
        double r = totalRevenue;
        totalRevenue = 0.0;
        return r;
    }
}
