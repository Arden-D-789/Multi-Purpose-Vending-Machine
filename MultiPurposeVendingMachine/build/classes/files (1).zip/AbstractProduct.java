package vendingmachine.products;

/**
 * Tüm ürün türleri için ortak soyut temel sınıf.
 */
public abstract class AbstractProduct {

    protected String slotId;
    protected String name;
    protected double price;
    protected int    stockQuantity;

    public AbstractProduct(String slotId, String name, double price, int stockQuantity) {
        this.slotId         = slotId;
        this.name           = name;
        this.price          = price;
        this.stockQuantity  = stockQuantity;
    }

    // ── Getters ────────────────────────────────────────────────
    public String getSlotId()       { return slotId; }
    public String getName()         { return name; }
    public double getPrice()        { return price; }
    public int    getStockQuantity(){ return stockQuantity; }
    public boolean isAvailable()    { return stockQuantity > 0; }

    // ── Setters / mutators ─────────────────────────────────────
    public void setPrice(double price)          { this.price = price; }
    public void setStockQuantity(int qty)       { this.stockQuantity = qty; }
    public void addStock(int amount)            { this.stockQuantity += amount; }

    /**
     * Stoktan bir adet düşürür.
     * @return Başarılıysa true, stok sıfırsa false
     */
    public boolean decrementStock() {
        if (stockQuantity > 0) {
            stockQuantity--;
            return true;
        }
        return false;
    }

    /** Ürün bilgilerini konsola yazdırır. */
    public abstract void displayInfo();
}
