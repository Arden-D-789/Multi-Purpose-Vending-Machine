package vendingmachine;

import vendingmachine.products.AbstractProduct;

/**
 * Müşteri işlemlerinin mantığını içerir.
 * Main.java (konsol arayüzü) tarafından kullanılır.
 */
public class UserLogic {

    private final VendingMachine machine = VendingMachine.getInstance();

    /** Belirtilen slotun mevcut ve stoklu olup olmadığını kontrol eder. */
    public boolean checkAvailability(String slot) {
        AbstractProduct p = machine.getProduct(slot.toUpperCase());
        return p != null && p.isAvailable();
    }

    /**
     * Slot'taki ürünün fiyatını döndürür.
     * @return Fiyat, veya ürün bulunamazsa -1.0
     */
    public double getItemPrice(String slot) {
        AbstractProduct p = machine.getProduct(slot.toUpperCase());
        return p != null ? p.getPrice() : -1.0;
    }

    /**
     * Satışı gerçekleştirir.
     * @param slot       Slot kodu (örn. "A1")
     * @param amountPaid Ödenen tutar
     * @return           Başarılıysa true
     */
    public boolean processSale(String slot, double amountPaid) {
        return machine.processSale(slot.toUpperCase(), amountPaid);
    }
}
