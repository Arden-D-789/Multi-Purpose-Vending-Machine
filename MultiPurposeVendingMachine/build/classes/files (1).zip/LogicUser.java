package vendingmachine.logic;

import vendingmachine.VendingMachine;
import vendingmachine.products.AbstractProduct;

/**
 * Müşteri işlemlerinin mantığını içerir.
 * GUI (TestGUI) tarafından kullanılır.
 *
 * Tüm veri erişimi tek VendingMachine singleton'ı üzerinden yapılır;
 * bu sayede konsol (UserLogic) ve GUI aynı envanteri paylaşır.
 */
public class LogicUser {

    private final VendingMachine machine = VendingMachine.getInstance();

    /** Slot'un mevcut ve stoklu olup olmadığını kontrol eder. */
    public boolean checkAvailability(String slot) {
        AbstractProduct p = machine.getProduct(slot.toUpperCase());
        return p != null && p.isAvailable();
    }

    /**
     * Slot'taki ürünün fiyatını döndürür.
     * @return Fiyat, ürün bulunamazsa -1.0
     */
    public double getItemPrice(String slot) {
        AbstractProduct p = machine.getProduct(slot.toUpperCase());
        return p != null ? p.getPrice() : -1.0;
    }

    /**
     * Satışı işler: stok düşer, gelire eklenir.
     * @return Başarılıysa true
     */
    public boolean processSale(String slot, double amountPaid) {
        return machine.processSale(slot.toUpperCase(), amountPaid);
    }
}
