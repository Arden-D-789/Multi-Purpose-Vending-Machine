package vendingmachine;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Ödeme hesaplama motoru.
 * Main.java (konsol arayüzü) tarafından kullanılır.
 *
 * NOT: vendingmachine.logic.ChangeCalculator, GUI tarafından kullanılan
 *      eşdeğer sınıftır; her ikisi de aynı mantığı paylaşır ancak
 *      farklı iç tip hiyerarşilerine sahiptir.
 */
public class ChangeCalculator {

    // ── Ödeme yöntemleri ──────────────────────────────────────
    public enum PaymentMethod {
        CASH, CREDIT_CARD, BANK_CARD
    }

    // ── Ödeme sonucu ──────────────────────────────────────────
    public static class PaymentResult {

        private final boolean             success;
        private final String              message;
        private final double              amountPaid;
        private final double              changeAmount;
        private final Map<String,Integer> changeBreakdown;

        public PaymentResult(boolean success, String message,
                             double amountPaid, double changeAmount,
                             Map<String,Integer> changeBreakdown) {
            this.success         = success;
            this.message         = message;
            this.amountPaid      = amountPaid;
            this.changeAmount    = changeAmount;
            this.changeBreakdown = changeBreakdown != null
                                        ? changeBreakdown
                                        : new LinkedHashMap<>();
        }

        public boolean             isSuccess()         { return success; }
        public String              getMessage()        { return message; }
        public double              getAmountPaid()     { return amountPaid; }
        public double              getChangeAmount()   { return changeAmount; }
        public Map<String,Integer> getChangeBreakdown(){ return changeBreakdown; }

        /** Konsolda makbuz yazdırır. */
        public void printReceipt() {
            System.out.println("\n  ╔══════════════════════════════╗");
            System.out.println("  ║          MAKBUZ              ║");
            System.out.println("  ╠══════════════════════════════╣");
            System.out.println("  ║ " + message);
            if (success) {
                System.out.printf ("  ║ Ödenen Tutar : $%-12.2f ║%n", amountPaid);
                System.out.printf ("  ║ Para Üstü   : $%-12.2f ║%n", changeAmount);
                if (changeAmount > 0.001 && !changeBreakdown.isEmpty()) {
                    System.out.println("  ║ Bozuk Para Dağılımı:         ║");
                    for (Map.Entry<String,Integer> e : changeBreakdown.entrySet()) {
                        System.out.printf("  ║   %dx %-22s ║%n",
                            e.getValue(), e.getKey());
                    }
                }
            }
            System.out.println("  ╚══════════════════════════════╝");
        }
    }

    // ── Ana işlem metodu ──────────────────────────────────────

    /**
     * Ödeme işlemini gerçekleştirir.
     *
     * @param price          Ürün fiyatı
     * @param amountTendered Kullanıcının ödediği tutar (nakit için)
     * @param method         Ödeme yöntemi
     * @return               İşlem sonucu
     */
    public static PaymentResult processPayment(double price,
                                               double amountTendered,
                                               PaymentMethod method) {
        // Kart ödemesi — anında onaylanır
        if (method == PaymentMethod.CREDIT_CARD || method == PaymentMethod.BANK_CARD) {
            String label = (method == PaymentMethod.CREDIT_CARD)
                            ? "Kredi Kartı" : "Banka Kartı";
            return new PaymentResult(
                true,
                label + " ödemesi onaylandı.",
                price, 0.0, null
            );
        }

        // Nakit ödeme
        if (amountTendered < price - 0.001) {
            return new PaymentResult(
                false,
                String.format("Yetersiz nakit. Gerekli: $%.2f, Verilen: $%.2f",
                    price, amountTendered),
                0.0, 0.0, null
            );
        }

        double change = Math.round((amountTendered - price) * 100.0) / 100.0;
        return new PaymentResult(
            true,
            String.format("Ödeme kabul edildi. Para üstü: $%.2f", change),
            amountTendered, change,
            buildChangeBreakdown(change)
        );
    }

    // ── Yardımcı: bozuk para dağılımı ─────────────────────────
    private static Map<String,Integer> buildChangeBreakdown(double change) {
        Map<String,Integer> breakdown = new LinkedHashMap<>();
        int cents = (int) Math.round(change * 100);

        int[]    values = { 500, 100, 25, 10, 5, 1 };
        String[] labels = { "$5 Banknot", "$1 Banknot",
                            "25¢ Çeyrek", "10¢ Dime",
                            "5¢ Nikel",   "1¢ Kuruş" };

        for (int i = 0; i < values.length; i++) {
            int count = cents / values[i];
            if (count > 0) {
                breakdown.put(labels[i], count);
                cents %= values[i];
            }
        }
        return breakdown;
    }
}
